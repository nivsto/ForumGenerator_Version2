﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
//using System.Threading.Tasks;
using System.Threading;
using System.Xml;
using System.IO;

namespace ForumGenerator_Client.Communication
{
    class Communicator
    {
        protected void sendLoginReq(int forumId, string userName, string password)
        {
            HttpWebRequest post_request = (HttpWebRequest)WebRequest.Create("http://localhost/");
            post_request.Method = "POST";
            post_request.ContentType = "text/xml";
            ASCIIEncoding encoding = new ASCIIEncoding();
            string username = "admin";
            string pass = "admin";
           
            XmlHandler x_test = new XmlHandler();
            LinkedList<Tuple<string, string>> test_args_list = new LinkedList<Tuple<string, string>>();
            Tuple<string, string> t1 = new Tuple<string, string>("UserName", username);
            Tuple<string, string> t2 = new Tuple<string, string>("Password", password);
            test_args_list.AddLast(t1);
            test_args_list.AddLast(t2);
            string logout_res = x_test.cCreateXml("adminlogin", test_args_list);
            byte[] data = Encoding.ASCII.GetBytes(logout_res);
            post_request.ContentLength = data.Length;
            Stream requestStream = post_request.GetRequestStream();
            requestStream.Write(data, 0, data.Length);



        }


        protected void sendLogoutReq(int forumId, string userName)
        {


        }

        protected void sendAdminLoginReq(string userName, string password)
        {


        }


        protected void sendAdminLogoutReq(string userName)
        {


        }

        protected void sendRegisterReq(int forumId, string userName, string password, string email, string signature)
        {


        }

        protected void sendGetForumsReq()
        {

        }


        protected void sendGetSubForumsReq()
        {

        }


        protected void sendGetDiscussionsReq()
        {

        }

        protected void sendGetCommentsReq()
        {

        }

        protected void sendGetUsersReq()
        {

        }

        protected void sendCreateNewForumReq(string userName, string password, string forumName, 
            string adminUserName, string adminPassword)
        {

        }

        protected void sendCreateNewSubForumReq(string userName, string password, int forumId, string subForumTitle)
        {

        }
        protected void sendCreateNewDiscussionReq(string userName, string password, int forumId, int subForumId, string title, string content)
        {

        }


        protected void sendCreateNewCommentReq(string userName, string password, int forumId, int subForumId, int discussionId, string content)
        {

        }


    }
}
